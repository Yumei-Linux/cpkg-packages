Doxmlparser
===========

This is a python package to make it easier to parse the XML output produced by doxygen.

The API is generated from the index.xsd and compound.xsd XML schema files using
Dave Kuhlman's generateDS https://www.davekuhlman.org/generateDS.html

See the examples directory to get an idea how to use the python module

