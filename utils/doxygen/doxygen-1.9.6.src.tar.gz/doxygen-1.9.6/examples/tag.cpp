/*! A class that is inherited from the external class Test.
*/

class Tag : public Example_Test
{
  public:
    /*! an overloaded member. */
    void example();
};
